function u=diffusion_scheme_2D_novel(u,Dxx,Dxy,Dyy,dt)
if(~isfinite(u)), keyboard, end
Dxx=repmat(Dxx,[1 1 size(u,3)]);
Dxy=repmat(Dxy,[1 1 size(u,3)]);
Dyy=repmat(Dyy,[1 1 size(u,3)]);

par=[0.00250699371368640,0.0165216035498513,0.0105032219986273,0.0126231826501856,0.0371316479801826,0.149351266328908,0.0270452037856226,0.111293917298023,0.312244700191003,0.000312162500147314,0.00919844402314123,0.0647390298896074,0.00206133954067190,0.316117574673944];

Mxx =[par(1)  par(2)  par(3)  par(2)  par(1);
      par(4)  par(5)  par(6)  par(5)  par(4); 
     -par(7) -par(8) -par(9) -par(8) -par(7);
      par(4)  par(5)  par(6)  par(5)  par(4); 
      par(1)  par(2)  par(3)  par(2)  par(1)];
Myy=Mxx';

Mxy=[par(10) par(11)   0    -par(11) -par(10);
     par(11) par(12)   0    -par(12) -par(11);
       0        0      0        0       0
    -par(11) -par(12)  0    par(12) par(11);
    -par(10) -par(11)  0    par(11) par(10)];

Mx= [par(13) par(14) par(13); 0 0 0; -par(13) -par(14) -par(13)];
My= Mx';

ux=imfilter(u,Mx,'conv','same','replicate');
uy=imfilter(u,My,'conv','same','replicate');
div1=imfilter(Dxx,Mx,'conv','same','replicate')+imfilter(Dxy,My,'conv','same','replicate');
div2=imfilter(Dxy,Mx,'conv','same','replicate')+imfilter(Dyy,My,'conv','same','replicate');
du1= div1.*ux+div2.*uy;
uxx=imfilter(u,Mxx,'conv','same','replicate');
uxy=imfilter(u,Mxy,'conv','same','replicate');
uyy=imfilter(u,Myy,'conv','same','replicate');
du2=uxx.*Dxx+2*uxy.*Dxy + uyy.*Dyy;
du=du1+du2;

u=u+du*dt;

u(~isfinite(u))=0;


	