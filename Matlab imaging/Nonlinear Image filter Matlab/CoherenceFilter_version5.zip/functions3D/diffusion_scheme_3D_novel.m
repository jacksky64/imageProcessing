function u=diffusion_scheme_3D_novel(u,Dxx,Dxy,Dxz,Dyy,Dyz,Dzz,dt)

%% Make the first order and second order derivate filters
par=[-0.00729513558761318,0.0127524911640676,0.0141756104159574,-1.70423143882112e-06,2.24987175153581e-06,2.41274902622035e-06,0.00118799439131056,-2.07239757014598e-05,7.76134206256290e-08,-0.000618516866985331,-1.98548958815912e-06,-0.00124365801801629,-4.35321187482740e-05,-0.00121352792194448,0.0226535218508319,-2.92186328090807e-05,-0.00125854666736655,-9.34908975512436e-05,0.00436407919594865,2.20272739315966e-06,0.0485976478003879,-1.40023218205554e-06,-9.54096668101639e-07,8.25634208356102e-07,-3.68423177151466e-06,3.30341012454277e-08,-1.34540521931386e-06,7.69729248445539e-07,-1.41779551233926e-06,-1.08640569126393e-06,-1.05923298797661e-06,6.89749237088083e-07,0.0109568478476058];
par=abs(par);
a=par(1:3); b=par(4:21); c=par(22:33);
Mx=zeros(3,3,3);
Mx(:,:,1)=[a(1) a(2) a(1); 0 0 0; -a(1) -a(2) -a(1)];
Mx(:,:,2)=[a(2) a(3) a(2); 0 0 0; -a(2) -a(3) -a(2)];
Mx(:,:,3)=[a(1) a(2) a(1); 0 0 0; -a(1) -a(2) -a(1)];
Mzz=zeros(5,5,5);
Mzz(:,:,1) =[b(1) b(2) b(3) b(2) b(1);
             b(2) b(4) b(5) b(4) b(2);
             b(3) b(5) b(6) b(5) b(3);
             b(2) b(4) b(5) b(4) b(2);
             b(1) b(2) b(3) b(2) b(1)];
Mzz(:,:,2) =[b(7) b(8)  b(9)  b(8)  b(7);
             b(8) b(10) b(11) b(10) b(8);
             b(9) b(11) b(12) b(11) b(9);
             b(8) b(10) b(11) b(10) b(8);
             b(7) b(8)  b(9)  b(8)  b(7)];
Mzz(:,:,3) =[-b(13) -b(14) -b(15) -b(14) -b(13);
             -b(14) -b(16) -b(17) -b(16) -b(14);
             -b(15) -b(17) -b(18) -b(17) -b(15);
             -b(14) -b(16) -b(17) -b(16) -b(14);
             -b(13) -b(14) -b(15) -b(14) -b(13)];
Mzz(:,:,4)=Mzz(:,:,2);
Mzz(:,:,5)=Mzz(:,:,1);
Mxz=zeros(5,5,5);
Mxz(:,:,1) =[ c(1)  c(2)  c(3)  c(2)  c(1);
              c(4)  c(5)  c(6)  c(5)  c(4);
                0     0     0     0     0 ;
             -c(4) -c(5) -c(6) -c(5) -c(4);   
             -c(1) -c(2) -c(3) -c(2) -c(1)];
Mxz(:,:,2) =[ c(7)   c(8)   c(9)   c(8)   c(7);
              c(10)  c(11)  c(12)  c(11)  c(10);
                0      0      0      0      0 ;
             -c(10) -c(11) -c(12) -c(11) -c(10);   
             -c(7)  -c(8)  -c(9)  -c(8)  -c(7)];
Mxz(:,:,4)=-Mxz(:,:,2);
Mxz(:,:,5)=-Mxz(:,:,1);
Mxy= permute(Mxz,[1 3 2]); Myz=permute(Mxz,[2 3 1]);
My = permute(Mx,[2 1 3]); Mz= permute(Mx,[2 3 1]);
Mxx= permute(Mzz,[3 1 2]); Myy= permute(Mzz,[2 3 1]);

%% Do the filtering and Diffusion
div1=imfilter(u,Mx,'conv','same','replicate').*(imfilter(Dxx,Mx,'conv','same','replicate')+imfilter(Dxy,My,'conv','same','replicate')+imfilter(Dxz,Mz,'conv','same','replicate'));
div2=imfilter(u,My,'conv','same','replicate').*(imfilter(Dxy,Mx,'conv','same','replicate')+imfilter(Dyy,My,'conv','same','replicate')+imfilter(Dyz,Mz,'conv','same','replicate'));
div3=imfilter(u,Mz,'conv','same','replicate').*(imfilter(Dxz,Mx,'conv','same','replicate')+imfilter(Dyz,My,'conv','same','replicate')+imfilter(Dzz,Mz,'conv','same','replicate'));
du1= div1+div2+div3;
clear div1; clear div2; clear div3;

uxx=imfilter(u,Mxx,'conv','same','replicate');
uyy=imfilter(u,Myy,'conv','same','replicate');
uzz=imfilter(u,Mzz,'conv','same','replicate');
uxy=imfilter(u,Mxy,'conv','same','replicate');
uxz=imfilter(u,Mxz,'conv','same','replicate');
uyz=imfilter(u,Myz,'conv','same','replicate');
du2 = Dxx.*uxx + Dyy.*uyy + Dzz.*uzz + 2* Dxy.*uxy +  2*Dxz.*uxz + 2*Dyz.*uyz;
clear uxx; clear uyy; clear uzz; clear uxy; clear uxz; clear uyz;
du=du2+du1;

u=u+du*dt;
u(~isfinite(u))=0;


	