% compile mex file


mex mex/perform_nlmeans_mex.cpp
% mex mex/perform_nlmeans.cpp -o perform_nl_means_mex
% mex mex/compute_pairwise_distance.cpp
% mex mex/denoising_nn.cpp